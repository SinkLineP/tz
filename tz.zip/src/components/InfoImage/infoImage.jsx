import React from 'react'

const infoImage = () => {
    return (
        <div>
            <h1>Инфо картинка</h1>   
        </div>
    )
}

export default infoImage
