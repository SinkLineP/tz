import React from 'react';
// import "approach.scss";

const approach = () => {
    return (
        <div>
            <h1>Підхід до навчання</h1>
        </div>
    )
}

export default approach;

//rafce
