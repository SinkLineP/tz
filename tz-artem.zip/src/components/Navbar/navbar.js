import React from 'react'

const navbar = () => {
    return (
        <div>
            <h1>Navbar</h1>
        </div>
    )
}

export default navbar
