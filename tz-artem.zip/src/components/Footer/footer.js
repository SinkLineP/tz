import React from 'react'

const footer = () => {
    return (
        <div>
            <h1>Footer</h1>
        </div>
    )
}

export default footer
