import React from 'react'

const infoDirector = () => {
    return (
        <div>
            <h1>Директор закладу</h1>
        </div>
    )
}

export default infoDirector
