import React from 'react'

const directions = () => {
    return (
        <div>
            <h1>Напрямки діяльності центру</h1>
        </div>
    )
}

export default directions
