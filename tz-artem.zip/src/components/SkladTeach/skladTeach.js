import React from 'react'

const skladTeach = () => {
    return (
        <div>
            <h1>skladTeach</h1>
        </div>
    )
}

export default skladTeach
