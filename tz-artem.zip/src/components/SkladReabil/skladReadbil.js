import React from 'react'

const skladReadbil = () => {
    return (
        <div>
            <h1>skladReadbil</h1>
        </div>
    )
}

export default skladReadbil
