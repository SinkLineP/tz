import React from 'react'

const questions = () => {
    return (
        <div>
           <h1>Вопросы</h1> 
        </div>
    )
}

export default questions
