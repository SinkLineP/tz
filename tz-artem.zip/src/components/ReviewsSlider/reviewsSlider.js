import React from 'react'

const reviewsSlider = () => {
    return (
        <div>
            <h1>Slider</h1>
        </div>
    )
}

export default reviewsSlider
