import React from 'react'

const documents = () => {
    return (
        <div>
            <h1>Документи закладу</h1>
        </div>
    )
}

export default documents
